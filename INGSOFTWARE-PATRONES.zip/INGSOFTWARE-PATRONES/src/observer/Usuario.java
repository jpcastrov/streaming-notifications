package observer;

public class Usuario {
    
}
