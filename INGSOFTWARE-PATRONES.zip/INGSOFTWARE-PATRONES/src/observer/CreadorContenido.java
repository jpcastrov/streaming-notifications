package observer;

public class CreadorContenido {
    
}
