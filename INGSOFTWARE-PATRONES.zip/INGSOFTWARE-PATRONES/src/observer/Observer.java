package observer;

public class Observer {
    
}
