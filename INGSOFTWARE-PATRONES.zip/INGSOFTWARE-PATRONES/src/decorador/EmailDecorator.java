package decorador;

public class EmailDecorator {
    
}
