package decorador;

public class PrioridadDecorator {
    
}
