package decorador;

public class PushDecorator {
    
}
