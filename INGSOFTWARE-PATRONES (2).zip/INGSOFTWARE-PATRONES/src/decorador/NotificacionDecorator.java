package decorador;

public class NotificacionDecorator {
    
}
