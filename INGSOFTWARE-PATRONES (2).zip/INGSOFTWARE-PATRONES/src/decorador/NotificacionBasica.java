package decorador;

public class NotificacionBasica {
    
}
